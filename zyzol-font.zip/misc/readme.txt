1) You cannot sell the font
2) You cannot misrepresent the origin of the font (ie. cannot take credit for its creation)
3) You cannot modify the font source file
4) You can use the font to create commercially viable works
5) If you redistrubute the font, you must include the original license, as well as obey the first 3 rules

· Designed by Szymon Furjan
 
· Visit my my FontSpace profile to find more fonts: https://www.fontspace.com/szymon-furjan
· Visit my portfolio to find more about me: https://www.furjandesign.com/
· Follow me on Twitter: @szymonfurjan